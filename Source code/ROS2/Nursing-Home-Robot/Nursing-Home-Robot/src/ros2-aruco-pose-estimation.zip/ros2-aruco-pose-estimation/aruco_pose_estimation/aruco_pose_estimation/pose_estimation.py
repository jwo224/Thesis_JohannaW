#!/usr/bin/env python3

# Code taken and readapted from:
# https://github.com/GSNCodes/ArUCo-Markers-Pose-Estimation-Generation-Python/tree/main

# Python imports
import math
import numpy as np
import cv2
import tf_transformations

# ROS2 imports
from rclpy.impl import rcutils_logger

# ROS2 message imports
from geometry_msgs.msg import Pose
from geometry_msgs.msg import PoseArray
from aruco_interfaces.msg import ArucoMarkers

# utils import python code
from aruco_pose_estimation.utils import aruco_display


def quaternion_from_rotation_matrix_3x3(R: np.array) -> np.array:
    """
    Convert a 3x3 rotation matrix to quaternion [x, y, z, w].

    This replaces tf_transformations.quaternion_from_matrix(), which can crash
    with:
        numpy.linalg.LinAlgError: Matrix is not positive definite

    That error can happen when the rotation matrix is numerically imperfect.
    """
    R = np.asarray(R, dtype=np.float64)

    if R.shape != (3, 3):
        return np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float64)

    if not np.all(np.isfinite(R)):
        return np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float64)

    # Project the matrix onto the closest valid rotation matrix.
    # This improves numerical robustness.
    try:
        U, _, Vt = np.linalg.svd(R)
        R = U @ Vt

        if np.linalg.det(R) < 0:
            U[:, -1] *= -1
            R = U @ Vt
    except Exception:
        return np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float64)

    m00, m01, m02 = R[0, 0], R[0, 1], R[0, 2]
    m10, m11, m12 = R[1, 0], R[1, 1], R[1, 2]
    m20, m21, m22 = R[2, 0], R[2, 1], R[2, 2]

    trace = m00 + m11 + m22

    try:
        if trace > 0.0:
            s = 0.5 / math.sqrt(max(trace + 1.0, 1e-12))
            w = 0.25 / s
            x = (m21 - m12) * s
            y = (m02 - m20) * s
            z = (m10 - m01) * s
        elif m00 > m11 and m00 > m22:
            s = 2.0 * math.sqrt(max(1.0 + m00 - m11 - m22, 1e-12))
            w = (m21 - m12) / s
            x = 0.25 * s
            y = (m01 + m10) / s
            z = (m02 + m20) / s
        elif m11 > m22:
            s = 2.0 * math.sqrt(max(1.0 + m11 - m00 - m22, 1e-12))
            w = (m02 - m20) / s
            x = (m01 + m10) / s
            y = 0.25 * s
            z = (m12 + m21) / s
        else:
            s = 2.0 * math.sqrt(max(1.0 + m22 - m00 - m11, 1e-12))
            w = (m10 - m01) / s
            x = (m02 + m20) / s
            y = (m12 + m21) / s
            z = 0.25 * s
    except Exception:
        return np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float64)

    quaternion = np.array([x, y, z, w], dtype=np.float64)
    norm_quat = np.linalg.norm(quaternion)

    if norm_quat < 1e-12 or not np.isfinite(norm_quat):
        return np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float64)

    return quaternion / norm_quat


def pose_estimation(rgb_frame: np.array, depth_frame: np.array, aruco_detector: cv2.aruco.ArucoDetector, marker_size: float,
                    matrix_coefficients: np.array, distortion_coefficients: np.array,
                    pose_array: PoseArray, markers: ArucoMarkers) -> list[np.array, PoseArray, ArucoMarkers]:
    """
    rgb_frame - Frame from the RGB camera stream
    depth_frame - Depth frame from the depth camera stream
    matrix_coefficients - Intrinsic matrix of the calibrated camera
    distortion_coefficients - Distortion coefficients associated with your camera
    pose_array - PoseArray message to be published
    markers - ArucoMarkers message to be published

    return:
    frame - The frame with the axis drawn on it
    pose_array - PoseArray with computed poses of the markers
    markers - ArucoMarkers message containing markers id number and pose
    """

    corners, marker_ids, rejected = aruco_detector.detectMarkers(image=rgb_frame)

    frame_processed = rgb_frame
    logger = rcutils_logger.RcutilsLogger(name="aruco_node")

    # If markers are detected
    if len(corners) > 0 and marker_ids is not None:

        logger.debug("Detected {} markers.".format(len(corners)))

        # show the detected markers bounding boxes once per frame
        frame_processed = aruco_display(
            corners=corners,
            ids=marker_ids,
            image=frame_processed
        )

        for i, marker_id in enumerate(marker_ids):
            try:
                # Alternative code version using solvePnP
                tvec, rvec, quat = my_estimatePoseSingleMarkers(
                    corners=corners[i],
                    marker_size=marker_size,
                    camera_matrix=matrix_coefficients,
                    distortion=distortion_coefficients
                )
            except Exception as e:
                logger.warn(f"Skipping marker {marker_id[0]} because pose estimation failed: {e}")
                continue

            # draw frame axes
            try:
                frame_processed = cv2.drawFrameAxes(
                    image=frame_processed,
                    cameraMatrix=matrix_coefficients,
                    distCoeffs=distortion_coefficients,
                    rvec=rvec,
                    tvec=tvec,
                    length=0.05,
                    thickness=3
                )
            except Exception as e:
                logger.warn(f"Could not draw axes for marker {marker_id[0]}: {e}")

            if depth_frame is not None:
                try:
                    # get the centroid of the pointcloud
                    centroid = depth_to_pointcloud_centroid(
                        depth_image=depth_frame,
                        intrinsic_matrix=matrix_coefficients,
                        corners=corners[i]
                    )

                    # log comparison between depthcloud centroid and tvec estimated positions
                    logger.info(f"depthcloud centroid = {centroid}")
                    logger.info(f"tvec = {tvec[0]} {tvec[1]} {tvec[2]}")
                except Exception as e:
                    logger.warn(f"Depth centroid failed for marker {marker_id[0]}: {e}")
                    centroid = None
            else:
                centroid = None

            # compute pose from the rvec and tvec arrays
            pose = Pose()

            if depth_frame is not None and centroid is not None:
                # use computed centroid from depthcloud as estimated pose
                pose.position.x = float(centroid[0])
                pose.position.y = float(centroid[1])
                pose.position.z = float(centroid[2])
            else:
                # use tvec from aruco estimator as estimated pose
                pose.position.x = float(tvec[0])
                pose.position.y = float(tvec[1])
                pose.position.z = float(tvec[2])

            pose.orientation.x = float(quat[0])
            pose.orientation.y = float(quat[1])
            pose.orientation.z = float(quat[2])
            pose.orientation.w = float(quat[3])

            # add the pose and marker id to the pose_array and markers messages
            pose_array.poses.append(pose)
            markers.poses.append(pose)
            markers.marker_ids.append(int(marker_id[0]))

    return frame_processed, pose_array, markers


def my_estimatePoseSingleMarkers(corners, marker_size, camera_matrix, distortion) -> tuple[np.array, np.array, np.array]:
    """
    Estimate rvec and tvec for one detected ArUco marker.

    corners:
        detected corners for one marker
    marker_size:
        physical marker size in meters
    camera_matrix:
        camera intrinsic matrix
    distortion:
        camera distortion coefficients

    returns:
        tvec, rvec, quaternion [x, y, z, w]
    """
    marker_points = np.array([
        [-marker_size / 2.0,  marker_size / 2.0, 0.0],
        [ marker_size / 2.0,  marker_size / 2.0, 0.0],
        [ marker_size / 2.0, -marker_size / 2.0, 0.0],
        [-marker_size / 2.0, -marker_size / 2.0, 0.0],
    ], dtype=np.float32)

    # solvePnP returns the rotation and translation vectors
    retval, rvec, tvec = cv2.solvePnP(
        objectPoints=marker_points,
        imagePoints=corners,
        cameraMatrix=camera_matrix,
        distCoeffs=distortion,
        flags=cv2.SOLVEPNP_IPPE_SQUARE
    )

    if not retval:
        raise RuntimeError("cv2.solvePnP failed")

    rvec = rvec.reshape(3, 1)
    tvec = tvec.reshape(3, 1)

    rotation_3x3, _ = cv2.Rodrigues(rvec)

    # Robust conversion to quaternion.
    quaternion = quaternion_from_rotation_matrix_3x3(rotation_3x3)

    return tvec, rvec, quaternion


def depth_to_pointcloud_centroid(depth_image: np.array, intrinsic_matrix: np.array,
                                 corners: np.array) -> np.array:
    """
    This function takes a depth image and the corners of a quadrilateral as input,
    and returns the centroid of the corresponding pointcloud.

    Args:
        depth_image: A 2D numpy array representing the depth image.
        corners: A list of 4 tuples, each representing the (x, y) coordinates of a corner.

    Returns:
        A tuple (x, y, z) representing the centroid of the segmented pointcloud.
    """

    # Get image parameters
    height, width = depth_image.shape

    # Check if all corners are within image bounds
    # corners has shape (1, 4, 2)
    corners_indices = np.array([(int(x), int(y)) for x, y in corners[0]])

    for x, y in corners_indices:
        if x < 0 or x >= width or y < 0 or y >= height:
            raise ValueError("One or more corners are outside the image bounds.")

    # bounding box of the polygon
    x_min = int(min(corners_indices[:, 0]))
    x_max = int(max(corners_indices[:, 0]))
    y_min = int(min(corners_indices[:, 1]))
    y_max = int(max(corners_indices[:, 1]))

    # create array of pixels inside the polygon defined by the corners
    points = []
    for x in range(x_min, x_max):
        for y in range(y_min, y_max):
            if is_pixel_in_polygon(pixel=(x, y), corners=corners_indices):
                points.append([x, y, depth_image[y, x]])

    if len(points) == 0:
        raise ValueError("No depth pixels found inside marker polygon.")

    # Convert points to numpy array
    points = np.array(points, dtype=np.float64)

    # create pointcloud
    pointcloud = []
    for x, y, d in points:
        z = d / 1000.0
        x_3d = (x - intrinsic_matrix[0, 2]) * z / intrinsic_matrix[0, 0]
        y_3d = (y - intrinsic_matrix[1, 2]) * z / intrinsic_matrix[1, 1]
        pointcloud.append([x_3d, y_3d, z])

    # Calculate centroid from pointcloud
    centroid = np.mean(np.array(pointcloud, dtype=np.float64), axis=0)

    return centroid


def is_pixel_in_polygon(pixel: tuple, corners: np.array) -> bool:
    """
    This function takes a pixel and a list of corners as input, and returns whether the pixel is inside the polygon
    defined by the corners. This function uses the ray casting algorithm to determine if the pixel is inside the
    polygon.
    """

    # Initialize counter for number of intersections
    num_intersections = 0

    # Iterate over each edge of the polygon
    for i in range(len(corners)):
        x1, y1 = corners[i]
        x2, y2 = corners[(i + 1) % len(corners)]

        # Check if the pixel is on the same y-level as the edge
        if (y1 <= pixel[1] < y2) or (y2 <= pixel[1] < y1):
            # Calculate the x-coordinate of the intersection point
            x_intersection = (x2 - x1) * (pixel[1] - y1) / (y2 - y1) + x1

            # Check if the intersection point is to the right of the pixel
            if x_intersection > pixel[0]:
                num_intersections += 1

    # Return whether the number of intersections is odd
    return num_intersections % 2 == 1